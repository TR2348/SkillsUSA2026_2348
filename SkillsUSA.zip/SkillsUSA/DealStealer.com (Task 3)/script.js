/* -------------------------
   EMBEDDED PIXEL-ART SPRITES (BASE64)
   (Simple placeholder 64x64 icons – replace with your own if you like)
-------------------------- */
const SPRITES = {
    toiletPaper: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAQAAACqG9kiAAAAF0lEQVR4Ae3BAQ0AAADCoPdPbQ8HFAAAAAAAAAAAwG0G0QAAc3v0XQAAAABJRU5ErkJggg==",
    alarmClock:  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAQAAACqG9kiAAAAF0lEQVR4Ae3BAQ0AAADCoPdPbQ8HFAAAAAAAAAAAwG0G0QAAc3v0XQAAAABJRU5ErkJggg==",
    cat:         "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAQAAACqG9kiAAAAF0lEQVR4Ae3BAQ0AAADCoPdPbQ8HFAAAAAAAAAAAwG0G0QAAc3v0XQAAAABJRU5ErkJggg==",
    uranium:     "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAQAAACqG9kiAAAAF0lEQVR4Ae3BAQ0AAADCoPdPbQ8HFAAAAAAAAAAAwG0G0QAAc3v0XQAAAABJRU5ErkJggg=="
};

/* -------------------------
   PREDEFINED INVENTORY
   Now with random stock (1–5) + templates
-------------------------- */
const inventory = [
    { 
        name: "Toliet Paper", 
        desc: "You know what to do.", 
        price: 5,
        sprite: SPRITES.toiletPaper,
        stock: Math.floor(Math.random() * 5) + 1
    },
    { 
        name: "Alarm Clock", 
        desc: "May cause hearing loss.", 
        price: 10,
        sprite: SPRITES.alarmClock,
        stock: Math.floor(Math.random() * 5) + 1
    },
    { 
        name: "Your neighbor's cat", 
        desc: "It's no longer their problem", 
        price: 0.63,
        sprite: SPRITES.cat,
        stock: 1
    },
    { 
        name: "1lb of Enriched Uranium", 
        desc: "Don't drop it...", 
        price: 900,
        sprite: SPRITES.uranium,
        stock: Math.floor(Math.random() * 5) + 1
    },
    {
        name: "ADMIN EMAIL!!!",
        desc: "admin@tylerco.com",
        price: 0,
        sprite: "",
        stock:1
    },
    {
        name: "ADMIN PASSWORD!!!",
        desc: "dontstealmypasswordandsellitonmywebsite",
        price: 0,
        sprite: "",
        stock:1
    }
];

let currentIndex = 0;
let cart = {};

// Player inventory: { itemName: { name, sprite, qty, totalValue } }
let playerInventory = {};

// Manager / sales state
let isAdminLoggedIn = false;
let totalGrossSales = 0;
let totalTaxCollected = 0;
let totalItemsSold = 0;
let totalTransactions = 0;

/* -------------------------
   PAGE NAVIGATION
-------------------------- */
function hideAllPages() {
    document.getElementById("storePage").style.display = "none";
    document.getElementById("checkoutPage").style.display = "none";
    document.getElementById("managerPage").style.display = "none";
    document.getElementById("inventoryPage").style.display = "none";
}

function goBack() {
    hideAllPages();
    document.getElementById("mainMenu").style.display = "block";
}

function openShop() {
    document.getElementById("mainMenu").style.display = "none";
    hideAllPages();
    document.getElementById("storePage").style.display = "block";
    updateDisplay();
}

function openCheckout() {
    document.getElementById("mainMenu").style.display = "none";
    hideAllPages();
    document.getElementById("checkoutPage").style.display = "block";
    renderCart();
}

function openInventory() {
    document.getElementById("mainMenu").style.display = "none";
    hideAllPages();
    document.getElementById("inventoryPage").style.display = "block";
    renderPlayerInventory();
}

function openManager() {
    document.getElementById("mainMenu").style.display = "none";
    hideAllPages();
    document.getElementById("managerPage").style.display = "block";

    if (!isAdminLoggedIn) {
        document.getElementById("managerLogin").style.display = "block";
        document.getElementById("managerDashboard").style.display = "none";
    } else {
        document.getElementById("managerLogin").style.display = "none";
        document.getElementById("managerDashboard").style.display = "block";
        renderSalesSummary();
        renderInventoryTable();
    }
}

/* -------------------------
   MANAGER LOGIN
-------------------------- */
function handleManagerLogin() {
    const email = document.getElementById("managerEmail").value.trim();
    const password = document.getElementById("managerPassword").value;
    const errorEl = document.getElementById("loginError");

    if (email === "admin@tylerco.com" &&
        password === "dontstealmypasswordandsellitonmywebsite") {

        isAdminLoggedIn = true;
        errorEl.innerText = "";

        // Enable neon-green dark mode
        document.body.classList.add("admin-mode");

        document.getElementById("managerLogin").style.display = "none";
        document.getElementById("managerDashboard").style.display = "block";

        renderSalesSummary();
        renderInventoryTable();
    } else {
        errorEl.innerText = "Invalid email or password.";
    }
}

/* -------------------------
   STORE ITEM DISPLAY
-------------------------- */
function updateDisplay() {
    if (inventory.length === 0) return;

    const item = inventory[currentIndex];

    document.getElementById("itemName").innerText = item.name;
    document.getElementById("displayName").innerText = item.name;
    document.getElementById("displayDesc").innerText = item.desc;
    document.getElementById("itemSprite").src = item.sprite || "";

    const priceBox = document.getElementById("displayPrice");
    const buyBtn = document.getElementById("storeBuyBtn");

    if (item.stock > 0) {
        priceBox.innerText = `$${item.price.toFixed(2)}  |  Stock: ${item.stock}`;
        buyBtn.disabled = false;
        buyBtn.innerText = "Buy";
        buyBtn.style.opacity = "1";
    } else {
        priceBox.innerText = "OUT OF STOCK";
        buyBtn.disabled = true;
        buyBtn.innerText = "Unavailable";
        buyBtn.style.opacity = "0.5";
    }
}

function nextItem() {
    if (inventory.length === 0) return;
    currentIndex = (currentIndex + 1) % inventory.length;
    updateDisplay();
}

function prevItem() {
    if (inventory.length === 0) return;
    currentIndex = (currentIndex - 1 + inventory.length) % inventory.length;
    updateDisplay();
}

/* -------------------------
   CART SYSTEM WITH STOCK
-------------------------- */
function addToCart() {
    if (inventory.length === 0) return;

    const item = inventory[currentIndex];

    if (item.stock <= 0) {
        alert("This item is out of stock!");
        return;
    }

    item.stock--;

    if (!cart[item.name]) {
        cart[item.name] = { ...item, qty: 1 };
    } else {
        cart[item.name].qty++;
    }

    alert(`${item.name} added to cart!`);

    updateDisplay();
}

function renderCart() {
    const container = document.getElementById("cartItems");
    const totalEl = document.getElementById("cartTotal");
    container.innerHTML = "";

    let subtotal = 0;

    const names = Object.keys(cart);
    if (names.length === 0) {
        container.innerHTML = "<p>Your cart is empty.</p>";
        totalEl.innerText = "";
        return;
    }

    names.forEach(name => {
        const item = cart[name];
        const itemTotal = item.price * item.qty;
        subtotal += itemTotal;

        const div = document.createElement("div");
        div.className = "cart-item";
        div.innerHTML = `
            <strong>${item.name}</strong><br>
            $${item.price.toFixed(2)} each<br>
            Quantity: ${item.qty}<br>
            Line total: $${itemTotal.toFixed(2)}
        `;
        container.appendChild(div);
    });

    const tax = subtotal * 0.08;
    const total = subtotal + tax;

    totalEl.innerHTML = `
        Subtotal: $${subtotal.toFixed(2)}<br>
        Tax (8%): $${tax.toFixed(2)}<br>
        <strong>Total: $${total.toFixed(2)}</strong>
    `;
}

/* -------------------------
   FINAL PURCHASE + RECEIPT
-------------------------- */
function finalizePurchase() {
    if (Object.keys(cart).length === 0) {
        alert("Your cart is empty!");
        return;
    }

    let receipt = "===== DEALSTEALER RECEIPT =====\n\n";
    let subtotal = 0;
    let itemsSoldThisTxn = 0;

    for (let name in cart) {
        const item = cart[name];
        const line = item.price * item.qty;
        subtotal += line;
        itemsSoldThisTxn += item.qty;

        // Update player inventory
        if (!playerInventory[name]) {
            playerInventory[name] = {
                name: item.name,
                sprite: item.sprite,
                qty: item.qty,
                totalValue: line
            };
        } else {
            playerInventory[name].qty += item.qty;
            playerInventory[name].totalValue += line;
        }

        receipt += `${item.name}\n`;
        receipt += `  Qty: ${item.qty}\n`;
        receipt += `  Price: $${item.price.toFixed(2)}\n`;
        receipt += `  Subtotal: $${line.toFixed(2)}\n\n`;
    }

    const tax = subtotal * 0.08;
    const total = subtotal + tax;

    receipt += `Subtotal: $${subtotal.toFixed(2)}\n`;
    receipt += `Tax (8%): $${tax.toFixed(2)}\n`;
    receipt += `TOTAL: $${total.toFixed(2)}\n\n`;
    receipt += "Thank you for shopping at DealStealer!";

    alert(receipt);

    // Update sales stats
    totalGrossSales += total;
    totalTaxCollected += tax;
    totalItemsSold += itemsSoldThisTxn;
    totalTransactions += 1;

    cart = {};
    renderCart();

    if (isAdminLoggedIn) {
        renderSalesSummary();
        renderInventoryTable();
    }
}

/* -------------------------
   PLAYER INVENTORY – RPG BAG
-------------------------- */
function renderPlayerInventory() {
    const bagEl = document.getElementById("inventoryBag");
    const names = Object.keys(playerInventory);

    if (names.length === 0) {
        bagEl.textContent = "+------------------------+\n" +
                            "|   Your bag is empty   |\n" +
                            "+------------------------+";
        return;
    }

    let lines = [];
    lines.push("+--------------------------------------+");
    lines.push("|            PLAYER INVENTORY          |");
    lines.push("+--------------------------------------+");

    names.forEach(name => {
        const item = playerInventory[name];
        const line = `| ${item.name}  x${item.qty}  ($${item.totalValue.toFixed(2)})`;
        const padded = line.padEnd(38, " ") + "|";
        lines.push(padded);
    });

    lines.push("+--------------------------------------+");

    bagEl.textContent = lines.join("\n");
}

/* -------------------------
   MANAGER – SALES SUMMARY
-------------------------- */
function renderSalesSummary() {
    const el = document.getElementById("salesSummary");
    el.innerHTML = `
        <p>Total Gross Sales: $${totalGrossSales.toFixed(2)}</p>
        <p>Total Tax Collected: $${totalTaxCollected.toFixed(2)}</p>
        <p>Total Items Sold: ${totalItemsSold}</p>
        <p>Total Transactions: ${totalTransactions}</p>
    `;
}

/* -------------------------
   MANAGER – INVENTORY TABLE
-------------------------- */
function renderInventoryTable() {
    const container = document.getElementById("inventoryTable");
    container.innerHTML = "";

    if (inventory.length === 0) {
        container.innerHTML = "<p>No items in inventory.</p>";
        return;
    }

    const table = document.createElement("table");
    table.className = "manager-table";

    const thead = document.createElement("thead");
    thead.innerHTML = `
        <tr>
            <th>Item</th>
            <th>Description</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Sprite</th>
            <th>Actions</th>
        </tr>
    `;
    table.appendChild(thead);

    const tbody = document.createElement("tbody");

    inventory.forEach((item, index) => {
        const tr = document.createElement("tr");

        tr.innerHTML = `
            <td>${item.name}</td>
            <td>${item.desc}</td>
            <td>$${item.price.toFixed(2)}</td>
            <td>${item.stock}</td>
            <td>${item.sprite ? "Embedded" : "None"}</td>
            <td>
                <button class="pixel-btn" onclick="showEditItem(${index})">Update</button>
                <button class="pixel-btn" onclick="deleteItem(${index})">Delete</button>
            </td>
        `;

        tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    container.appendChild(table);
}

/* -------------------------
   MANAGER – EDIT / DELETE
-------------------------- */
function showEditItem(index) {
    const item = inventory[index];
    const newPrice = prompt(`New price for "${item.name}" (current: ${item.price}):`, item.price);
    if (newPrice === null) return;

    const priceNum = Number(newPrice);
    if (isNaN(priceNum) || priceNum < 0) {
        alert("Invalid price.");
        return;
    }

    const newStock = prompt(`New stock for "${item.name}" (current: ${item.stock}):`, item.stock);
    if (newStock === null) return;

    const stockNum = Number(newStock);
    if (!Number.isInteger(stockNum) || stockNum < 0) {
        alert("Invalid stock.");
        return;
    }

    item.price = priceNum;
    item.stock = stockNum;

    renderInventoryTable();
    updateDisplay();
}

function deleteItem(index) {
    const item = inventory[index];
    if (!confirm(`Delete "${item.name}" from inventory?`)) return;

    inventory.splice(index, 1);

    if (currentIndex >= inventory.length) {
        currentIndex = 0;
    }

    renderInventoryTable();
    if (inventory.length > 0) {
        updateDisplay();
    } else {
        document.getElementById("itemName").innerText = "No items";
        document.getElementById("displayName").innerText = "No items";
        document.getElementById("displayDesc").innerText = "";
        document.getElementById("displayPrice").innerText = "";
        document.getElementById("itemSprite").src = "";
        document.getElementById("storeBuyBtn").disabled = true;
    }
}

/* -------------------------
   MANAGER – ADD NEW ITEM
-------------------------- */
function addNewItem() {
    const name = document.getElementById("newItemName").value.trim();
    const desc = document.getElementById("newItemDesc").value.trim();
    const priceStr = document.getElementById("newItemPrice").value;
    const stockStr = document.getElementById("newItemStock").value;
    const sprite = document.getElementById("newItemSprite").value.trim();
    const errorEl = document.getElementById("addItemError");

    errorEl.innerText = "";

    if (!name || !desc || !priceStr || !stockStr) {
        errorEl.innerText = "Name, description, price, and stock are required.";
        return;
    }

    const price = Number(priceStr);
    const stock = Number(stockStr);

    if (isNaN(price) || price < 0) {
        errorEl.innerText = "Invalid price.";
        return;
    }

    if (!Number.isInteger(stock) || stock < 0) {
        errorEl.innerText = "Invalid stock.";
        return;
    }

    inventory.push({
        name,
        desc,
        price,
        sprite,
        stock
    });

    document.getElementById("newItemName").value = "";
    document.getElementById("newItemDesc").value = "";
    document.getElementById("newItemPrice").value = "";
    document.getElementById("newItemStock").value = "";
    document.getElementById("newItemSprite").value = "";

    renderInventoryTable();
    if (inventory.length === 1) {
        currentIndex = 0;
        updateDisplay();
    }
}
