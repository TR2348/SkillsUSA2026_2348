import random
from collections import deque

def allocate_seats(arr):
    n = len(arr)
    queue = deque()
    occupied = set()
    final_seat = [None] * n

    # Initialize queue with (original_index, preferred_seat)
    for i, seat in enumerate(arr):
        queue.append((i, seat))

    while queue:
        idx, seat = queue.popleft()

        if seat not in occupied:
            # Seat is free → assign it
            occupied.add(seat)
            final_seat[idx] = seat
        else:
            # Seat taken → move to back with seat+1
            queue.append((idx, seat + 1))

    return final_seat


# Generate 16 random preferred seats between 1 and 16
preferred_seats = [random.randint(1, 16) for _ in range(16)]

print("Random preferred seats:", preferred_seats)

result = allocate_seats(preferred_seats)
print("Final assigned seats:", result)